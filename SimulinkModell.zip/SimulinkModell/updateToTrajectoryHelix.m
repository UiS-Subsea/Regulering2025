function trajectory = updateToTrajectoryHelix(initState, R, h, n, resolution)
    trajectory.x = [];
    trajectory.y = [];
    trajectory.z = [];
    trajectory.psi = [];
    trajectory.resolution = resolution;

    distance = 2 * pi * n * sqrt(R^2 + (h / (2 * pi * n))^2);
    steps = ceil(distance / resolution) + 1;

    for i = 0:steps
        k = 2 * pi * n * i / steps;
        trajectory.x(end+1) = initState(1) + R * cos(k);
        trajectory.y(end+1) = initState(2) + R * sin(k);
        trajectory.z(end+1) = initState(3) + (h / (2 * pi * n)) * k;
    end

    for i = 1:steps
        dx = trajectory.x(i+1) - trajectory.x(i);
        dy = trajectory.y(i+1) - trajectory.y(i);
        trajectory.psi(end+1) = atan2(dy, dx);
    end
    trajectory.psi(end+1) = trajectory.psi(end); 
end
