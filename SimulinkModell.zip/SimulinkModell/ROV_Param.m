clc; clear;
s = tf('s');

ROV.PosInit = [0; 0; 0; 0; 0; 0]; % Initial position for simulation
ROV.VelInit = [0; 0; 0; 0; 0; 0]; % Initial velocity for simulation

%% General Parameters
ROV.g = 9.81; % [m/s^2]
ROV.Rho = 1000; % density [kg/m^3]

ROV.Mass = 13.5; % [kg]
ROV.Volume = 0.013856778; % Volume of fluid displaced by ROV [m^3]
ROV.COG = [0, 0, 0];        % Center of gravity
ROV.COB = [0, 0, -0.01];    % Center of buyonacy

ROV.Inertia = diag([0.26, 0.23, 0.37]); % Inertia matrix [kg*m^2]
ROV.AddedMass = diag([6.356673886738174, 7.120600295756984, 18.68632686153499, 0.1857656307475919, 0.13482334942966032, 0.22151046664469023]);
ROV.HydroLinearDamping = diag([13.7, 0, 33, 0, 0.8, 0]);            % Linear damping coefficients
ROV.HydroQuadraticDamping = diag([141, 217, 190, 1.19, 0.47, 1.5]); % Quadratic damping

%% Thruster Parameters

% TAM (6x8): [unit direction vector; [distance from COG] x [unit direction vector]]
r_1 = [ 0.235; -0.243; -0.131];     e_1 = [0; 0; -1];                   % Thruster 1: VVF
r_2 = [ 0.235;  0.243; -0.131];     e_2 = [0; 0; -1];                   % Thruster 2: VHF
r_3 = [-0.235; -0.243; -0.131];     e_3 = [0; 0; -1];                   % Thruster 3: VVB
r_4 = [-0.235;  0.243; -0.131];     e_4 = [0; 0; -1];                   % Thruster 4: VHB
r_5 = [ 0.235; -0.15;   0;];        e_5 = [cosd(45); sind(45); 0];      % Thruster 5: HVF
r_6 = [ 0.235;  0.15;   0];         e_6 = [cosd(-45); sind(-45); 0];    % Thruster 6: HHF
r_7 = [-0.235; -0.15;   0];         e_7 = [cosd(135); sind(135); 0];    % Thruster 7: HVB
r_8 = [-0.235;  0.15;   0];         e_8 = [cosd(-135); sind(-135); 0];  % Thruster 8: HHB

ROV.ThrusterMatrix = [[e_1 ; cross(r_1,e_1)], ... 
                      [e_2 ; cross(r_2,e_2)], ...
                      [e_3 ; cross(r_3,e_3)], ...
                      [e_4 ; cross(r_4,e_4)], ...
                      [e_5 ; cross(r_5,e_5)], ...
                      [e_6 ; cross(r_6,e_6)], ...
                      [e_7 ; cross(r_7,e_7)], ...
                      [e_8 ; cross(r_8,e_8)]]; 

% Relationship between force output and input
ROV.ThrusterIn = [-1.000 -0.875 -0.750 -0.625 -0.500 -0.375 -0.250 -0.125 0.000 0.125 0.250 0.375 0.500 0.625 0.750 0.875 1.000] * 100; % [%]
ROV.ThrusterOut = [-2.8140 -2.3507 -1.8874 -1.3908 -0.8942 -0.5874 -0.2807 -0.1403 0 0.1403 0.2807 0.5874 0.8942 1.3908 1.8874 2.3507 2.8140] * 9.81; % [N]
ROV.TauMax = [sum(max(ROV.ThrusterOut) * abs(ROV.ThrusterMatrix(1,:)));
              sum(max(ROV.ThrusterOut) * abs(ROV.ThrusterMatrix(2,:)));
              sum(max(ROV.ThrusterOut) * abs(ROV.ThrusterMatrix(3,:)));
              sum(max(ROV.ThrusterOut) * abs(ROV.ThrusterMatrix(4,:)));
              sum(max(ROV.ThrusterOut) * abs(ROV.ThrusterMatrix(5,:)));
              sum(max(ROV.ThrusterOut) * abs(ROV.ThrusterMatrix(6,:)))];

thrusterDynamics = (-2.1766 * 10^3 * s + 2.6754 * 10^6) / (s^3 + 143.2756*s^2 + 2.9302 * 10^4*s + 2.6754 * 10^6); 

%% Controller settings
ROV.dt = 0.01;

ROV.MPC_Kp = [72.6;     81.8;       98.3;       5;          5;          3.95];  % Surge, Sway, Heave, Roll, Pitch, Yaw
ROV.MPC_Ki = [379;      454;        409;        2;          2;          39.4];
ROV.MPC_Kd = [0;        0;          0;          5;          5;          0];

MPC.PredictionHorizon = 15; % Need to also be updated in Reference block in Simulink!
MPC.ControlHorizon = 14;
MPC.StepHorizon = 0.1;
nlobj = setupMPC(MPC.StepHorizon, MPC.PredictionHorizon, MPC.PredictionHorizon);

%% Reference: Comment out the ones which is not needed.
desiredVelocity = 0.3;
resolution = 0.005;

WP = [0 0 0 0;
      1 0 0 0;
      1 1 0 0;
      1 1 1 0;
      1 1 1 pi/4];

Reference = updateToTrajectoryWaypoints(ROV.PosInit(1:3), 0, resolution);
%Reference = updateToTrajectoryHelix(ROV.PosInit(1:3), 2, 3, 2, resolution);
Reference.desiredVelocity = desiredVelocity;
%Reference = updateToWaypoints(ROV.PosInit(1:3), WP, 10, resolution);

%% Creating Bus objects for Simulink:
ROV_Bus = Simulink.Bus.createObject(ROV);
ROV_Bus = evalin('base', ROV_Bus.busName);
assignin('base', 'ROV', ROV);
assignin('base', 'ROV_Bus', ROV_Bus);

REF_Bus = Simulink.Bus.createObject(Reference);
REF_Bus = evalin('base', REF_Bus.busName);
assignin('base', 'Reference', Reference);
assignin('base', 'REF_Bus', REF_Bus);

MPC_Bus = Simulink.Bus.createObject(MPC);
MPC_Bus = evalin('base', MPC_Bus.busName);
assignin('base', 'MPC', MPC);
assignin('base', 'MPC_Bus', MPC_Bus);