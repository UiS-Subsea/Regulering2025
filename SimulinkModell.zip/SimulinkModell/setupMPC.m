function nlobj = setupMPC(T, P, C)

%% Kinematic NMPC Model
nx = 8;              % [x; y; z; psi; u_act; v_act; w_act; r_act]
nu = 4;              % [u; v; w; r]
Ts = T;              % sampling time
PredictionHorizon = P;
ControlHorizon = C;

% NMPC Object
nlobj = nlmpc(nx, nx, nu);
nlobj.Ts = Ts;
nlobj.PredictionHorizon = PredictionHorizon;
nlobj.ControlHorizon = ControlHorizon;
nlobj.Model.IsContinuousTime = false;

% State Function
nlobj.Model.StateFcn = @(x,u) stateFcn(x, u, Ts);
nlobj.Model.OutputFcn = @(x,u) x;

% Cost Function
nlobj.Optimization.CustomCostFcn = @myCostFunction;

% Constraints
nlobj.ManipulatedVariables(1).Min = -0.47;       % u_min
nlobj.ManipulatedVariables(1).Max = 0.47;        % u_max
nlobj.ManipulatedVariables(1).RateMin = -0.9 * Ts;   % Delta u_min
nlobj.ManipulatedVariables(1).RateMax = 0.9 * Ts;    % Delta u_max

nlobj.ManipulatedVariables(2).Min = -0.42;       % v_min
nlobj.ManipulatedVariables(2).Max = 0.42;        % v_max
nlobj.ManipulatedVariables(2).RateMin = -0.82 * Ts;   % Delta v_min
nlobj.ManipulatedVariables(2).RateMax = 0.82 * Ts;    % Delta v_max

nlobj.ManipulatedVariables(3).Min = -0.66;       % w_min
nlobj.ManipulatedVariables(3).Max = 0.66;        % w_max
nlobj.ManipulatedVariables(3).RateMin = -1.3 * Ts;   % Delta w_min
nlobj.ManipulatedVariables(3).RateMax = 1.3 * Ts;    % Delta w_max

nlobj.ManipulatedVariables(4).Min = -4.4;         % r_min
nlobj.ManipulatedVariables(4).Max = 4.4;          % r_max
nlobj.ManipulatedVariables(4).RateMin = -18 * Ts;   % Delta r_min
nlobj.ManipulatedVariables(4).RateMax = 18 * Ts;    % Delta r_max

% Validate the NMPC
x0 = [0; 0; 0; 0; 0; 0; 0; 0];  % initial state
u0 = [0; 0; 0; 0];  % initial input
validateFcns(nlobj, x0, u0);


end

function xnext = stateFcn(x, u, Ts)
    
    K_tau = diag([1/max(Ts,0.2), 1/max(Ts,0.18), 1/max(Ts,0.26), 1/max(Ts,0.11)]);
    eta = x(1:4);
    v_act = x(5:8);
    v_act_next = v_act + Ts * K_tau * (u - v_act);

    f_eta = @(eta_local, v_local) ...
        [cos(eta_local(4)), -sin(eta_local(4)), 0, 0;
         sin(eta_local(4)),  cos(eta_local(4)), 0, 0;
         0,                  0,                 1, 0;
         0,                  0,                 0, 1] * v_local;

    % RK4
    k1 = f_eta(eta, v_act);
    k2 = f_eta(eta + 0.5 * Ts * k1, v_act);
    k3 = f_eta(eta + 0.5 * Ts * k2, v_act);
    k4 = f_eta(eta + Ts * k3, v_act);
    eta_next = eta + (Ts / 6) * (k1 + 2*k2 + 2*k3 + k4);
    
    xnext = [eta_next; v_act_next];
end

function J = myCostFunction(X, U, e, data)

    Q = diag([5 5 5 5 0 0 0 0]);
    R = diag([1 1 1 1]);
    % If large errors: R = max(1,max(abs(data.CurrentStates(1:4,1) -
    %data.References(1:4,1))))*diag([1 1 1 1]); 
    e = (X(2:end,:) - data.References(:,:))';
    e(4,:) = atan2(sin(e(4,:)), cos(e(4,:)));
    U = U';
    J = 0;
    for i = 1 : data.PredictionHorizon
        J = J + e(:,i)' * Q * e(:,i) + U(:,i)' * R * U(:,i);
    end
end
