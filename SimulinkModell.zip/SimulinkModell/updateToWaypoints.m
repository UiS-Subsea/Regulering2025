function reference = updateToWaypoints(initState, WP, DeltaTime, resolution)

reference.x = initState(1)*ones(1, 5 / resolution); % 5 seconds at start
reference.y = initState(2)*ones(1, 5 / resolution);
reference.z = initState(3)*ones(1, 5 / resolution);
reference.psi = zeros(1, 5 / resolution);
reference.resolution = resolution;
reference.desiredVelocity = 1; % So that the function in Simulink updates reference correct.

for i = 2:size(WP,1)
    nextPt   = WP(i, 1:4);   
    reference.x   = [reference.x, repmat(nextPt(1), 1, DeltaTime / resolution)];
    reference.y   = [reference.y, repmat(nextPt(2), 1, DeltaTime / resolution)];
    reference.z   = [reference.z, repmat(nextPt(3), 1, DeltaTime / resolution)];
    reference.psi = [reference.psi, repmat(nextPt(4), 1, DeltaTime / resolution)];
end 

end