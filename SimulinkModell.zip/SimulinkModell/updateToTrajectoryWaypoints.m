function trajectory = updateToTrajectoryWaypoints(initState, TrajVersion, resolution)
    trajectory.x = [];
    trajectory.y = [];
    trajectory.z = [];
    trajectory.psi = [];
    trajectory.resolution = resolution;

    pos0 = [initState(1); initState(2); initState(3)];

    switch TrajVersion
        case 0  % Lawnmower pattern
            displacements = [
                4.0,  0.0, 0.0;
                4.0,  2.0, 0.0;
                0.0,  2.0, 0.0;
                0.0,  4.0, 0.0;
                4.0,  4.0, 0.0;
                4.0,  6.0, 0.0;
                0.0,  6.0, 0.0];

        case 1  % Sawtooth
            displacements = [
                1,  1, 0.0;
                2, -1, 0.0;
                3,  1, 0.0;
                4, -1, 0.0;
                5,  1, 0.0;
                6, -1, 0.0;
                7,  1, 0.0];

        case 2 % Pipeline
            displacements = [
                1,  1, 0.0;
                2,  1, 0.0;
                3,  0, 0.0;
                6,  0, 0.0;
                8, -1, 0.0;
                9, -1, 0.0;
               10,  0, 0.0];
    end

    WP = pos0';
    for i = 1:size(displacements,1)
        WP(end+1, :) = pos0' + displacements(i, :);
    end
    
    for i = 1:(size(WP,1)-1)
        xi = WP(i, 1); yi = WP(i, 2); zi = WP(i, 3);
        xe = WP(i+1, 1); ye = WP(i+1, 2); ze = WP(i+1, 3);

        distance = sqrt((xe - xi)^2 + (ye - yi)^2 + (ze - zi)^2);
        steps = ceil(distance / resolution) + 1;

        for j = 0:steps
            if i > 1 && j == 0
                continue; 
            end
            k = j / steps;
            trajectory.x(end+1) = xi + k * (xe - xi);
            trajectory.y(end+1) = yi + k * (ye - yi);
            trajectory.z(end+1) = zi + k * (ze - zi);
            trajectory.psi(end+1) = atan2(ye - yi, xe - xi);
        end
    end
end
