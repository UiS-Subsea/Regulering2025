function skogestad(out, frihetsgrad)

%% Data fra Simulink
% Frihetsgrad: 1 = Jag, 2 = Svai, 3 = Hiv, 6 = Gir

t = out.nu.Time(:);
u = out.tau.Data(:,frihetsgrad);
y = squeeze(out.nu.Data(frihetsgrad,1,:));

%% Stegets start
threshold   = 0.01;
for i = 2:length(u)
    delta_u = abs(u(i) - u(i-1));
    if delta_u > threshold
        stepIndex = i;
        break;
    end
end
if isempty(stepIndex)
    error('Det er ikke gjort et sprang');
end
t0 = t(stepIndex);

%% Finner stabile vinduer før og etter steget
margin       = 5;      
std_tol      = 0.05;    
window       = 20;     

% Før steg
indexBeforeStep = max(stepIndex - margin, 1);

for e = indexBeforeStep:-1:window
    s = e - window + 1;
    if std(y(s:e)) < std_tol
        i1 = s; i2 = e;
        break;
    end
end
y0 = mean(y(i1:i2));
u0 = mean(u(i1:i2));

% Etter steg
startA = stepIndex + margin;
y_afterStep = y(startA:end);
u_afterStep = u(startA:end);

stable_after_step = false;
for e = numel(y_afterStep):-1:window
    s = e - window + 1;
    if std(y_afterStep(s:e)) < std_tol
        i1 = s; i2 = e;
        stable_after_step = true;
        break;
    end
end

if ~stable_after_step
    warning('Prosessen stabiliserte seg ikke etter steget innenfor gitt toleranse. Parameterestimering avbrytes.');
    return;
end

y_inf = mean(y_afterStep(i1:i2));
u_inf = mean(u_afterStep(i1:i2));

%% Prosessforsterkning K
Delta_u = u_inf - u0;
Delta_y = y_inf - y0;
K       = Delta_y / Delta_u;

%% Finner dødtiden theta
noise_tol = 0.01 * abs(Delta_y);
idx_th    = find(abs(y(stepIndex - window : stepIndex + window) - y0) >= noise_tol, 1, 'first');
t_th      = t(idx_th + stepIndex - window);
theta     = t_th - t0;

%% Finner tidskonstanten tau
y63   = y0 + 0.632*Delta_y;
if Delta_y > 0
    idx_tau = find(y >= y63, 1, 'first');
else
    idx_tau = find(y <= y63, 1, 'first');
end
t_tau = t(idx_tau);
tau   = (t_tau - t0) - theta;

%% Utskrift av estimerte parametre
fprintf('K     = %.4f\n', K);
fprintf('θ     = %.4f s\n', theta);
fprintf('τ     = %.4f s\n', tau);

%% Beregner hvor godt estimatet samsvarer mot målt respons
y_est = zeros(numel(y),1);
for i = 1:numel(u)
    dt = t(i) - t0;
    if dt < theta
        y_est(i) = y0;
    else
        y_est(i) = y0 + K*Delta_u*(1 - exp(-(dt - theta)/tau));
    end
end
fitPct = 100*(1 - sum((y - y_est).^2) / sum((y - mean(y)).^2));
fprintf('Samsvar mot målt respons: %.2f%%\n', fitPct);

%% Plotter FOPDT-estimat mot målt respons
figure; 
grid on;
plot(t,y,'b-','LineWidth',1.5);
hold on; 
plot(t,y_est, 'r--','LineWidth',1.5);
xlabel('Tid [s]');
ylabel('Tilstand');
legend('Logget respons','FOPDT-modell');

%% Skogestad-tuning
c  = 1.5;      
tau_c = theta; 
Kp = tau/(K*(tau_c + tau));
Ti = min(tau, c*(tau_c + tau));
Ki = Kp/Ti;
Td = 0;

fprintf('Kp = %.4f\n', Kp);
fprintf('Ki = %.4f (Ti = %.4f s)\n', Ki, Ti);
fprintf('Kd = %.4f\n', Td);


end