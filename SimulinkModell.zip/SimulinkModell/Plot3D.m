
function Plot3D(out, step, markerSize)

%% Create figure for ROV
fig1 = figure('Name', 'ROV', 'Units', 'normalized', 'OuterPosition', [0 0 1 1]);%figure('Name','ROV', 'Position', [50, 50, 1200, 500]);
plot3(out.x.Data(:,2), out.y.Data(:,2), out.z.Data(:,2), 'b.', 'MarkerSize', markerSize);
hold on;
grid on;
axis equal;
xlabel('X-akse'); ylabel('Y-akse'); zlabel('Z-akse');
title('ROV - Settpunkt (NED)');
dt = out.x.Time(2) - out.x.Time(1);

% Box dimensions
L = 0.5; 
W = 0.3; 
H = 0.3; 

vertices = [-L/2 -W/2 -H/2;  L/2 -W/2 -H/2;  L/2  W/2 -H/2; -L/2  W/2 -H/2;  % Bottom face
            -L/2 -W/2  H/2;  L/2 -W/2  H/2;  L/2  W/2  H/2; -L/2  W/2  H/2]; % Top face

faces = [1 2 3 4; 
         5 6 7 8;
         1 2 6 5;
         2 3 7 6;
         3 4 8 7;
         4 1 5 8];

% Transformation object
t = hgtransform;
patch('Vertices', vertices, 'Faces', faces, ...
      'FaceColor', 'cyan', 'EdgeColor', 'black', 'LineWidth', 1.5, 'Parent', t);

view(3);

trajectory = animatedline('Marker', '.', 'MarkerSize', 8, 'Color', 'r');

%% Create another figure for data
fig2 = figure('Name', 'Yaw, Pitch, Roll Info', 'Position', [1000, 400, 300, 200]); 
info_text = uicontrol('Style', 'text', ...
                      'Units', 'normalized', ...
                      'Position', [0.1, 0.1, 0.8, 0.8], ... % Centered text
                      'FontSize', 12, 'FontWeight', 'bold', ...
                      'HorizontalAlignment', 'left', ...
                      'BackgroundColor', 'white', ...
                      'String', 'Initializing...');



%% Loop to update position and rotation
for i = 1:step:length(out.x.data(:,1))
    
    if i == 1
        loopStart = tic;
    end
    if ~isvalid(fig1) || ~isvalid(fig2)
        break;
    end

    % Update center position
    x = out.x.Data(i,1);
    x_ref = out.x.Data(i,2);
    y = out.y.Data(i,1);
    y_ref = out.y.Data(i,2);
    z = out.z.Data(i,1);
    z_ref = out.z.Data(i,2);
   
    % Update rotation angles
    yaw = out.psi.Data(i,1);
    yaw_ref = out.psi.Data(i,2);  
    pitch = out.theta.Data(i,1);
    pitch_ref = out.theta.Data(i,2);  
    roll = out.phi.Data(i,1);
    roll_ref = out.phi.Data(i,2);  

    % Create transformation matrices
    Ryaw = makehgtform('zrotate', yaw);  % Rotate around Z-axis
    Rpitch = makehgtform('yrotate', pitch); % Rotate around Y-axis
    Rroll = makehgtform('xrotate', roll); % Rotate around X-axis
    Tmove = makehgtform('translate', [x, y, z]); % Move the box
    t.Matrix = Tmove * Rroll * Rpitch * Ryaw;

    elapsed = toc(loopStart);
    if elapsed < dt*step
        pause(dt*step - elapsed);
    end
    loopStart = tic;
    % Update trajectory
    addpoints(trajectory, x, y, z);

    % Update the data
    set(info_text, 'String', sprintf( ...
    ['Time: %.2f s\n' ...
     'X: %.2f - Ref: %.2f\n' ...
     'Y: %.2f - Ref: %.2f\n' ...
     'Z: %.2f - Ref: %.2f\n' ...
     'Yaw: %.1f° - Ref: %.1f°\n' ...
     'Pitch: %.1f° - Ref: %.1f°\n' ...
     'Roll: %.1f° - Ref: %.1f°'], ...
     out.x.Time(i), x, x_ref, ...
     y, y_ref, ...
     z, z_ref, ...
     rad2deg(yaw), rad2deg(yaw_ref), ...
     rad2deg(pitch), rad2deg(pitch_ref), ...
     rad2deg(roll), rad2deg(roll_ref)));




    drawnow;
end
end