- Oppsett for Casadi på Jetson ligger vedlagt.

- Det er brukt kommunikasjonsskriptet fra:

https://github.com/UiS-Subsea/Kommunikasjon-2023

og bygget videre på for å inkludere MPC-en, en må derfor ha funksjonene og driverne som er definert i dette repoet for at det skal fungere.